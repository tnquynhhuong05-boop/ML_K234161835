

from StudentManagement.MainWindow import Ui_MainWindow


class LoginMainWindowEx(Ui_MainWindow):
    def __init__(self):
        pass

    def setupUi(self, MainWindow):
        super().setupUi(MainWindow)
        self.MainWindow=MainWindow

    def showWindow(self):
        self.MainWindow.show()
    def setupSignalAndSlot(self):
        self.p