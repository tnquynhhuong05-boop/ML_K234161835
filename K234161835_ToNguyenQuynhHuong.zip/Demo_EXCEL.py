import pandas as pd

dataframe = pd.read_excel("../dataset/SalesTransactions.xlsx")
print(dataframe)