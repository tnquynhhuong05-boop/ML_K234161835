import pandas as pd

df=pd.read_csv("../dataset/SalesTransactions.csv",
               sep='\t')
print(df)