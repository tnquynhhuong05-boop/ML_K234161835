import pandas as pd

df=pd.read_csv("../dataset/SalesTransactions.json",
               sep='\t')

print(df)
