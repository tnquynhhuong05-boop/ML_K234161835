import pandas as pd

df=pd.read_csv("../dataset/SalesTransactions.txt",
               sep='\t')

print(df)

""" Khi nào '..' : tùy thuộc vào cấp con bên trong """